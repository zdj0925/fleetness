The source code for the �ReplaceVistaIcon� tool was originally developed by

	Vlasta_@codeproject.com
	http://www.codeproject.com/KB/GDI/using_vista_icons.aspx

and is licensed under the �The Code Project Open License (CPOL)�.

See �LICENSE.html� for details.

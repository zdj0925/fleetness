//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by id3com.rc
//
#define IDS_PROJNAME                    100
#define IDR_ID3TAG                      101
#define IDR_ID3FRAME                    102
#define IDR_ID3FIELD                    104
#define IDR_ID3COMFIELDTEXT             105
#define IDR_ID3COMFIELDLONG             106
#define IDR_ID3COMFIELDPICTURE          107
#define IDR_TEXTCOLLECTION              108
#define IDS_UNEXPECTED_ERROR            0x0200
#define IDS_ERROR_BAD_FILENAME          513
#define IDS_ERROR_BAD_URL               514

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
